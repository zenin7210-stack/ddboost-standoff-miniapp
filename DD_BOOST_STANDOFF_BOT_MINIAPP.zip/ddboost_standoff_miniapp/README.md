# DD BOOST · Standoff 2

Telegram bot + Telegram Mini App for Standoff 2 rank boost orders. The app contains only boost ordering: mode, current rank, target rank, game nickname and automatic price. The bot stores orders in SQLite and lets the admin accept or reject them.

## Start the bot

1. Create a bot with `@BotFather` and copy its token.
2. Copy `.env.example` to `.env`; fill in `BOT_TOKEN`, your numeric `ADMIN_ID`, `ADMIN_USERNAME`, and the public HTTPS URL where `web/` is hosted.
3. Install Python 3.10 or newer, then run `pip install -r requirements.txt`.
4. Run `python bot.py`.
5. In `@BotFather`, set the bot's menu button to Web App with the same HTTPS URL. The `/start` reply keyboard also opens the Mini App.

Host the contents of `web/` on any HTTPS static host, such as GitHub Pages. Keep the Python bot process running on a Python host. The bot uses long polling, so it does not need a public server or webhook.

## Admin

- Set `ADMIN_ID` to the admin's numeric Telegram ID.
- New orders arrive with **Взять в работу** and **Отклонить** buttons.
- **Завершить заказ** sends the customer a completion notice.
- `/orders` lists the latest ten requests; `/myorders` shows a customer's latest five orders.
- Change `STEP_PRICES` in `bot.py` to update the price for each rank step. Prices are in Uzbek soum.

The bot intentionally does not request account passwords, Steam credentials, or payment receipts. The admin coordinates the details and payment after accepting an order.
