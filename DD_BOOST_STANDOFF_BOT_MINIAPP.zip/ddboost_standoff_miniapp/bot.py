import asyncio
import html
import json
import logging
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    WebAppInfo,
)
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "").lstrip("@")
WEBAPP_URL = os.getenv("WEBAPP_URL", "")
DB_PATH = Path(os.getenv("DB_PATH", Path(__file__).with_name("orders.sqlite3")))

RANKS = ["Калибровка", "Bronze", "Silver", "Gold", "Phoenix", "Ranger", "Champion", "Master", "Elite", "The Legend"]
MODES = {"mm": "Матчмейкинг", "duel": "Дуэли", "competitive": "Соревновательный"}
# Цена за переход на следующее звание; сумма заказа складывается из шагов.
STEP_PRICES = [3000, 4000, 6000, 9000, 13000, 18000, 25000, 35000, 50000]
dp = Dispatcher()


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT NOT NULL DEFAULT '',
            player_nick TEXT NOT NULL,
            mode TEXT NOT NULL,
            current_rank INTEGER NOT NULL,
            target_rank INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'new',
            created_at TEXT NOT NULL
        )""")


def calculate_price(start: int, end: int) -> int:
    if not 0 <= start < end < len(RANKS):
        raise ValueError("Invalid rank range")
    return sum(STEP_PRICES[start:end])


def money(value: int) -> str:
    return f"{value:,}".replace(",", " ")


def admin_keyboard(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Взять в работу", callback_data=f"status:active:{order_id}"),
        InlineKeyboardButton(text="❌ Отклонить", callback_data=f"status:rejected:{order_id}"),
    ], [InlineKeyboardButton(text="🏁 Завершить заказ", callback_data=f"status:done:{order_id}")]])


def order_text(row) -> str:
    nick = html.escape(row["player_nick"])
    username = html.escape(row["username"] or "нет")
    return (
        f"🆕 <b>Заказ DD BOOST #{row['id']}</b>\n"
        f"👤 Telegram: @{username} · ID <code>{row['user_id']}</code>\n"
        f"🎮 Режим: {MODES[row['mode']]}\n"
        f"🪪 Ник в игре: {nick}\n"
        f"🏅 {RANKS[row['current_rank']]} → {RANKS[row['target_rank']]}\n"
        f"💰 Цена: <b>{money(row['amount'])} сум</b>\n"
        f"📌 Статус: {row['status']}"
    )


@dp.message(CommandStart())
async def start(message: Message):
    if WEBAPP_URL.startswith("https://"):
        keyboard = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="⚡ Заказать буст", web_app=WebAppInfo(url=WEBAPP_URL))]],
            resize_keyboard=True,
            is_persistent=True,
        )
        await message.answer(
            "🔷 <b>DD BOOST · STANDOFF 2</b>\n\n"
            "Выбери режим, укажи текущий и желаемый ранг — Mini App рассчитает цену и отправит заказ сюда.",
            parse_mode="HTML",
            reply_markup=keyboard,
        )
    else:
        await message.answer(
            "🔷 <b>DD BOOST · STANDOFF 2</b>\n\n"
            "Mini App ещё не подключён. Администратору нужно указать HTTPS-ссылку в WEBAPP_URL.",
            parse_mode="HTML",
        )


@dp.message(F.web_app_data)
async def receive_order(message: Message, bot: Bot):
    try:
        payload = json.loads(message.web_app_data.data)
        mode = payload.get("mode")
        start_rank = int(payload.get("current_rank"))
        target_rank = int(payload.get("target_rank"))
        player_nick = str(payload.get("player_nick", "")).strip()[:32]
        if mode not in MODES or not player_nick:
            raise ValueError("Missing fields")
        amount = calculate_price(start_rank, target_rank)
    except (ValueError, TypeError, json.JSONDecodeError):
        await message.answer("Не получилось оформить заказ. Открой Mini App и проверь данные.")
        return

    with db() as con:
        cur = con.execute(
            """INSERT INTO orders (user_id, username, player_nick, mode, current_rank,
               target_rank, amount, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (message.from_user.id, message.from_user.username or "", player_nick, mode,
             start_rank, target_rank, amount, datetime.now(timezone.utc).isoformat()),
        )
        order_id = cur.lastrowid
        row = con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()

    await message.answer(
        f"✅ <b>Заявка #{order_id} отправлена!</b>\n\n"
        f"🎮 {MODES[mode]}\n🏅 {RANKS[start_rank]} → {RANKS[target_rank]}\n"
        f"💰 {money(amount)} сум\n\nАдминистратор подтвердит заказ и напишет тебе.",
        parse_mode="HTML",
    )
    if ADMIN_ID:
        await bot.send_message(ADMIN_ID, order_text(row), parse_mode="HTML", reply_markup=admin_keyboard(order_id))


@dp.callback_query(F.data.startswith("status:"))
async def update_order(call, bot: Bot):
    if call.from_user.id != ADMIN_ID:
        await call.answer("Нет доступа", show_alert=True)
        return
    _, status, order_id_raw = call.data.split(":")
    if status not in {"active", "rejected", "done"}:
        await call.answer("Неизвестный статус", show_alert=True)
        return
    order_id = int(order_id_raw)
    with db() as con:
        row = con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not row or row["status"] not in ({"new"} if status != "done" else {"active"}):
            await call.answer("Заказ уже обработан", show_alert=True)
            return
        con.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
    label = {"active": "взят в работу", "rejected": "отклонён", "done": "завершён"}[status]
    await call.message.edit_text(order_text(dict(row) | {"status": status}), parse_mode="HTML")
    try:
        if status == "active":
            admin_link = f"https://t.me/{ADMIN_USERNAME}" if ADMIN_USERNAME else None
            markup = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Написать администратору", url=admin_link)]]) if admin_link else None
            await bot.send_message(row["user_id"], f"✅ Заказ #{order_id} взят в работу. Напиши администратору, чтобы согласовать детали.", reply_markup=markup)
        elif status == "rejected":
            await bot.send_message(row["user_id"], f"Заказ #{order_id} отклонён. Если это ошибка, свяжись с администратором.")
        else:
            await bot.send_message(row["user_id"], f"🏁 Заказ #{order_id} завершён. Спасибо, что выбрал DD BOOST!")
    except Exception:
        logging.exception("Could not notify customer for order %s", order_id)
    await call.answer(f"Заказ {label}")


@dp.message(Command("orders"))
async def list_orders(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    with db() as con:
        rows = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 10").fetchall()
    if not rows:
        await message.answer("Заказов пока нет.")
        return
    for row in rows:
        await message.answer(order_text(row), parse_mode="HTML")


@dp.message(Command("myorders"))
async def my_orders(message: Message):
    with db() as con:
        rows = con.execute(
            "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 5",
            (message.from_user.id,),
        ).fetchall()
    if not rows:
        await message.answer("У тебя пока нет заказов. Нажми /start, чтобы оформить буст.")
        return
    statuses = {"new": "Новый", "active": "В работе", "rejected": "Отклонён", "done": "Завершён"}
    lines = [f"#{row['id']} · {RANKS[row['current_rank']]} → {RANKS[row['target_rank']]} · {statuses.get(row['status'], row['status'])}" for row in rows]
    await message.answer("📋 <b>Твои последние заказы</b>\n\n" + "\n".join(lines), parse_mode="HTML")


async def main():
    if not TOKEN:
        raise RuntimeError("Заполни BOT_TOKEN в .env")
    init_db()
    bot = Bot(TOKEN)
    await dp.start_polling(bot)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
