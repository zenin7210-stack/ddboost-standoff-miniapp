const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); tg.setHeaderColor?.('#090d14'); tg.setBackgroundColor?.('#090d14'); }
const ranks = ['Калибровка','Bronze','Silver','Gold','Phoenix','Ranger','Champion','Master','Elite','The Legend'];
const steps = [3000,4000,6000,9000,13000,18000,25000,35000,50000];
const current = document.querySelector('#current');
const target = document.querySelector('#target');
const price = document.querySelector('#price');
const submit = document.querySelector('#submit');
const nick = document.querySelector('#nick');
let mode = 'mm';
function fill(select, from) {
  select.innerHTML = '';
  ranks.forEach((rank, i) => {
    if (from !== null && i <= from) return;
    const option = document.createElement('option'); option.value = i; option.textContent = rank; select.append(option);
  });
}
function updateTarget() {
  const start = Number(current.value);
  fill(target, start);
  updatePrice();
}
function updatePrice() {
  if (!current.value || !target.value) { price.textContent = 'Выбери ранги'; submit.disabled = true; return; }
  const start = Number(current.value), end = Number(target.value);
  const amount = steps.slice(start, end).reduce((a,b)=>a+b,0);
  price.textContent = `${amount.toLocaleString('ru-RU')} сум`;
  submit.disabled = !nick.value.trim();
}
fill(current, null); current.value = '0'; updateTarget();
document.querySelectorAll('.mode').forEach(button => button.addEventListener('click', () => {
  document.querySelector('.mode.selected')?.classList.remove('selected'); button.classList.add('selected'); mode = button.dataset.mode;
}));
current.addEventListener('change', updateTarget); target.addEventListener('change', updatePrice); nick.addEventListener('input', updatePrice);
submit.addEventListener('click', () => {
  if (!tg) { document.querySelector('#notice').textContent = 'Открой Mini App из Telegram, чтобы отправить заявку.'; return; }
  const order = {mode, current_rank:Number(current.value), target_rank:Number(target.value), player_nick:nick.value.trim()};
  tg.sendData(JSON.stringify(order));
});
